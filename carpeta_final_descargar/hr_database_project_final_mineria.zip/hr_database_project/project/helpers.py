"""
helpers.py
==========
Funciones comunes reutilizables por todos los generadores.
"""

import random
import string
import datetime as dt
from typing import Iterable


# ============================================================================
# RANDOM PONDERADO
# ============================================================================

def weighted_choice(items: list[dict], weight_key: str = "weight",
                    value_key: str | None = None,
                    filter_fn=None):
    """
    Elige un item de una lista de dicts segun el peso.
    Si value_key se proporciona devuelve item[value_key], si no devuelve el dict completo.
    filter_fn: funcion opcional para filtrar previamente (lambda r: r['country_iso']=='ES')
    """
    candidates = [r for r in items if filter_fn(r)] if filter_fn else items
    if not candidates:
        return None
    weights = [float(r[weight_key]) for r in candidates]
    chosen = random.choices(candidates, weights=weights, k=1)[0]
    return chosen[value_key] if value_key else chosen


def weighted_bool(true_weight: float, false_weight: float) -> bool:
    """Devuelve True/False segun pesos."""
    return random.choices([True, False], weights=[true_weight, false_weight], k=1)[0]


def filter_rows(items: list[dict], **filters) -> list[dict]:
    """Filtra filas por columnas. Ej: filter_rows(rows, country_iso='ES', gender='Male')"""
    return [r for r in items if all(r.get(k) == v for k, v in filters.items())]


# ============================================================================
# FECHAS
# ============================================================================

def random_date_between(start: dt.date, end: dt.date) -> dt.date:
    """Fecha aleatoria entre dos fechas (inclusive)."""
    delta = (end - start).days
    if delta < 0:
        return start
    return start + dt.timedelta(days=random.randint(0, delta))


def random_birth_date(min_age: int, max_age: int, reference: dt.date) -> dt.date:
    """Fecha de nacimiento que cumpla un rango de edad respecto a reference."""
    earliest = reference.replace(year=reference.year - max_age)
    latest = reference.replace(year=reference.year - min_age)
    return random_date_between(earliest, latest)


def years_between(d1: dt.date, d2: dt.date) -> int:
    """Anos completos entre 2 fechas."""
    return d2.year - d1.year - ((d2.month, d2.day) < (d1.month, d1.day))


def months_between(d1: dt.date, d2: dt.date) -> int:
    """Meses completos entre 2 fechas."""
    return (d2.year - d1.year) * 12 + d2.month - d1.month


def to_datetime(d: dt.date | None) -> dt.datetime | None:
    """Convierte date a datetime (MongoDB necesita datetime)."""
    if d is None:
        return None
    if isinstance(d, dt.datetime):
        return d
    return dt.datetime.combine(d, dt.time.min)


# ============================================================================
# IDs Y CODIGOS
# ============================================================================

def generate_employee_id(country_iso: str, work_center_code: str, sequence: int) -> str:
    """
    Genera un employee_id con formato 'ES-MAD-000001'.
    El work_center_code ya viene como 'ES-MAD-HQ', extraemos el codigo de ciudad.
    """
    parts = work_center_code.split("-")
    city_code = parts[1] if len(parts) > 1 else "XXX"
    return f"{country_iso}-{city_code}-{sequence:06d}"


def generate_id_document(country_iso: str) -> str:
    """Genera un documento de identidad segun el formato del pais."""
    if country_iso == "ES":
        # DNI espanol: 8 digitos + letra
        digits = random.randint(10000000, 99999999)
        letter = "TRWAGMYFPDXBNJZSQVHLCKE"[digits % 23]
        return f"{digits}{letter}"
    elif country_iso == "MX":
        # CURP mexicano (18 caracteres alfanumericos simulados)
        return ''.join(random.choices(string.ascii_uppercase + string.digits, k=18))
    elif country_iso == "US":
        # SSN americano 999-99-9999
        return f"{random.randint(100,999)}-{random.randint(10,99)}-{random.randint(1000,9999)}"
    elif country_iso == "BR":
        # CPF brasileno (11 digitos formateados)
        return f"{random.randint(100,999)}.{random.randint(100,999)}.{random.randint(100,999)}-{random.randint(10,99)}"
    elif country_iso == "GB":
        # National Insurance Number AB123456C
        letters1 = ''.join(random.choices(string.ascii_uppercase, k=2))
        letters2 = random.choice(string.ascii_uppercase)
        return f"{letters1}{random.randint(100000,999999)}{letters2}"
    elif country_iso == "DE":
        # German tax ID 11 digitos
        return ''.join(random.choices(string.digits, k=11))
    elif country_iso == "FR":
        # NIR 13 digitos + 2 clave
        return ''.join(random.choices(string.digits, k=13)) + ' ' + ''.join(random.choices(string.digits, k=2))
    elif country_iso == "IT":
        # Codice Fiscale italiano 16 caracteres
        return ''.join(random.choices(string.ascii_uppercase + string.digits, k=16))
    elif country_iso == "PT":
        # NIF portugues 9 digitos
        return ''.join(random.choices(string.digits, k=9))
    elif country_iso == "AR":
        # CUIT argentino XX-XXXXXXXX-X
        return f"{random.randint(20,30)}-{random.randint(10000000,99999999)}-{random.randint(0,9)}"
    elif country_iso == "CL":
        # RUT chileno 99.999.999-K
        digits = random.randint(10000000, 99999999)
        check = str(digits % 11) if digits % 11 != 10 else "K"
        return f"{digits:,}-{check}".replace(",", ".")
    elif country_iso == "CO":
        # Cedula colombiana 8-10 digitos
        return ''.join(random.choices(string.digits, k=random.randint(8, 10)))
    elif country_iso == "PE":
        # DNI peruano 8 digitos
        return ''.join(random.choices(string.digits, k=8))
    else:
        # Fallback generico
        return ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))


def generate_iban(country_iso: str) -> str:
    """Genera un IBAN sintetico con formato pseudo-valido segun ISO 13616."""
    iban_lengths = {
        "ES": 24, "DE": 22, "FR": 27, "GB": 22, "IT": 27, "PT": 25,
        "NL": 18, "BE": 16, "PL": 28, "CH": 21, "IE": 22,
    }
    length = iban_lengths.get(country_iso, 22)
    # Para paises sin IBAN (LatAm, US) generamos un numero de cuenta simulado
    if country_iso not in iban_lengths:
        return ''.join(random.choices(string.digits, k=20))
    check_digits = f"{random.randint(10,99)}"
    bban_length = length - 4
    bban = ''.join(random.choices(string.digits, k=bban_length))
    return f"{country_iso}{check_digits}{bban}"


def generate_phone(country_iso: str) -> str:
    """Genera un telefono con prefijo internacional."""
    prefixes = {
        "ES":"+34","MX":"+52","US":"+1","CO":"+57","GB":"+44",
        "DE":"+49","FR":"+33","AR":"+54","BR":"+55","IT":"+39",
        "CL":"+56","PT":"+351","PE":"+51","IE":"+353","NL":"+31",
        "BE":"+32","PL":"+48","CH":"+41","UY":"+598","EC":"+593",
        "PY":"+595","CR":"+506","PA":"+507","DO":"+1809",
    }
    prefix = prefixes.get(country_iso, "+999")
    number = ''.join(random.choices(string.digits, k=9))
    return f"{prefix} {number}"


def generate_email(first_name: str, last_name: str, domain: str = "company.com") -> str:
    """Genera email del formato firstname.lastname@domain (sin tildes ni espacios)."""
    import unicodedata
    def normalize(s):
        s = unicodedata.normalize('NFD', s).encode('ascii', 'ignore').decode('ascii')
        return s.lower().replace(' ', '').replace("'", "")
    fn = normalize(first_name)
    ln = normalize(last_name).split()[0]  # primer apellido si hay 2
    suffix = random.randint(1, 999)
    # 30% sin sufijo, 70% con sufijo (para evitar colisiones masivas en 1.5M)
    if random.random() < 0.3:
        return f"{fn}.{ln}@{domain}"
    return f"{fn}.{ln}{suffix}@{domain}"


def generate_ss_number(country_iso: str) -> str:
    """Genera un numero de afiliacion a seguridad social."""
    if country_iso == "ES":
        # NUSS espanol: provincia(2)/numero(8)/control(2)
        return f"{random.randint(1,52):02d}/{random.randint(10000000,99999999)}/{random.randint(10,99):02d}"
    return ''.join(random.choices(string.digits, k=12))


def generate_address(city: str) -> str:
    """Genera una direccion sintetica simple."""
    streets = ["Calle Mayor","Avenida Libertad","Calle Real","Calle del Sol",
               "Plaza Mayor","Avenida de Espana","Calle Nueva","Paseo Maritimo",
               "Calle Cervantes","Avenida del Mar","Calle San Juan","Calle Larga"]
    return f"{random.choice(streets)} {random.randint(1,200)}, {random.randint(1,8)}{random.choice('ABCD')}"
