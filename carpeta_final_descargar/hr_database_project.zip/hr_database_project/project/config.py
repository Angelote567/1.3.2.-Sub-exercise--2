"""
config.py
=========
Variables globales y configuracion del proyecto.
Modificar aqui el numero de empleados a generar, conexion a MongoDB, paths, etc.
"""

import os
from pathlib import Path

# ============================================================================
# GENERACION
# ============================================================================
N_OUTPUTS = 1000              # Numero de empleados a generar (objetivo final: 1_500_000)
BATCH_SIZE = 100              # Tamano del batch para insertar en MongoDB
RANDOM_SEED = 42              # Semilla para reproducibilidad (None para aleatorio puro)
ID_OFFSET = 0    # Cambiar segun el companero

# ============================================================================
# RUTAS
# ============================================================================
PROJECT_ROOT = Path(__file__).resolve().parent
CSV_DIR = PROJECT_ROOT / "data" / "csvs"

# ============================================================================
# MONGODB
# ============================================================================
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
MONGO_DB_NAME = "hr_database"
MONGO_COLLECTION = "employees"

# ============================================================================
# RANGO TEMPORAL
# ============================================================================
# Fecha de referencia para "hoy" (consistencia entre ejecuciones)
import datetime as _dt
REFERENCE_DATE = _dt.date(2026, 2, 1)

# Rango de fechas de contratacion permitidas
MIN_HIRE_YEAR = 2005
MAX_HIRE_YEAR = REFERENCE_DATE.year

# Edad de los empleados (R01: minimo 16 anos al contratar; R02: 18-67 activos)
MIN_AGE_AT_HIRE = 18
MAX_AGE_ACTIVE = 67

# ============================================================================
# COHERENCIA / NEGOCIO
# ============================================================================
# Probabilidad de que un empleado este dado de baja (terminated)
TERMINATION_PROBABILITY = 0.15

# Multiplicadores de salario por nivel jerarquico (sobre el baseline del CSV)
SENIORITY_SALARY_MULT = {
    "Entry":    0.70,
    "Mid":      1.00,
    "Senior":   1.40,
    "Manager":  1.80,
    "Director": 2.50,
}

# Paises hispanohablantes (usan 2 apellidos)
HISPANIC_COUNTRIES = {"ES","MX","CO","AR","CL","PE","UY","EC","PY","CR","PA","DO"}

# ============================================================================
# LOGGING
# ============================================================================
LOG_LEVEL = "INFO"            # DEBUG, INFO, WARNING, ERROR
LOG_PROGRESS_EVERY = 100      # Mostrar progreso cada N registros
