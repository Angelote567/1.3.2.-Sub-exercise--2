"""
pipeline.py
===========
Pipeline principal de generacion de la base de datos sintetica de RRHH.

USO:
    python pipeline.py

Modificar N_OUTPUTS en config.py para cambiar el tamano del dataset.
"""

import logging
import random
import time
from helpers import weighted_choice, to_datetime, generate_employee_id
from csv_loader import load_all_csvs
from coherence_rules import validate_employee, validate_name_diversity
from mongodb_client import get_sink

from generators.profile import generate_profile
from generators.employment import generate_employment
from generators.compensation import generate_compensation
from generators.documentation import generate_documentation
from generators.osh import generate_osh
from generators.social_security import generate_social_security
from generators.resources import generate_resources
from generators.exit_process import generate_exit
from generators.history import generate_history

from config import (
    ID_OFFSET, N_OUTPUTS, BATCH_SIZE, RANDOM_SEED,
    LOG_LEVEL, LOG_PROGRESS_EVERY, ID_OFFSET
)


# =============================================================================
# LOGGING
# =============================================================================
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL),
    format="%(asctime)s | %(levelname)-7s | %(name)-20s | %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("pipeline")


# =============================================================================
# SERIALIZACION PARA MONGODB
# =============================================================================
def _serialize_dates(obj):
    """Convierte recursivamente date -> datetime (MongoDB no soporta date puro)."""
    import datetime as dt
    if isinstance(obj, dt.datetime):
        return obj
    if isinstance(obj, dt.date):
        return to_datetime(obj)
    if isinstance(obj, dict):
        return {k: _serialize_dates(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_serialize_dates(x) for x in obj]
    return obj


# =============================================================================
# GENERACION DE UN EMPLEADO COMPLETO
# =============================================================================
def generate_employee(csvs: dict, sequence: int) -> dict:
    """Genera un empleado completo con sus 9 bloques."""
    # 1) Elegir centro de trabajo (que determina el pais)
    work_center = weighted_choice(
        csvs["work_centers"],
        weight_key=None,  # work_centers no tiene weight
    ) if False else None
    # Para work_centers usamos uniforme entre los disponibles, pero ponderado por pais
    # Elegimos primero pais (con pesos del CSV) y despues un work_center de ese pais
    country_iso = weighted_choice(csvs["countries"], "weight", "iso_code")
    wc_pool = [w for w in csvs["work_centers"] if w["country_iso"] == country_iso]
    if not wc_pool:
        # Fallback a Espana
        wc_pool = [w for w in csvs["work_centers"] if w["country_iso"] == "ES"]
    work_center = random.choice(wc_pool)

    # 2) employee_id
    employee_id = generate_employee_id(country_iso, work_center["work_center_code"], sequence)

    # 3) Generar bloques en orden
    profile = generate_profile(csvs, employee_id, work_center)
    employment = generate_employment(csvs, profile, work_center)
    exit_block = generate_exit(csvs, employment)

    # R05: si se ha terminado, ajustar probation_period a la duracion real
    if exit_block.get("termination_date"):
        from config import REFERENCE_DATE
        td = exit_block["termination_date"]
        hd = employment["hire_date"]
        months_real = (td - hd).days // 30
        if employment["probation_period"] > months_real:
            employment["probation_period"] = max(0, months_real)

    compensation = generate_compensation(csvs, profile, employment)
    documentation = generate_documentation(csvs, profile, employment)
    osh = generate_osh(csvs, employment)
    social_security = generate_social_security(csvs, profile, employment)
    resources = generate_resources(csvs, employment, exit_block)
    history = generate_history(csvs, employment, exit_block)

    # 4) Eliminar campos auxiliares (los que empiezan por _)
    employment_clean = {k: v for k, v in employment.items() if not k.startswith("_")}

    employee = {
        "profile": profile,
        "employment": employment_clean,
        "compensation": compensation,
        "documentation": documentation,
        "history": history,
        "osh": osh,
        "social_security": social_security,
        "resources": resources,
        "exit": exit_block,
    }
    return employee


# =============================================================================
# PIPELINE PRINCIPAL
# =============================================================================
def run():
    if RANDOM_SEED is not None:
        random.seed(RANDOM_SEED)
        logger.info(f"Semilla aleatoria: {RANDOM_SEED}")

    start = time.time()
    logger.info(f"Iniciando generacion de {N_OUTPUTS} empleados (batch={BATCH_SIZE})")

    # Cargar todos los CSVs
    csvs = load_all_csvs()

    # Conectar al sink (MongoDB o JSONL fallback)
    sink = get_sink()

    # Generar empleados
    batch = []
    all_employees_for_validation = []
    n_invalid = 0
    violations_by_rule = {}


    for i in range(1, N_OUTPUTS + 1):
        emp = generate_employee(csvs, sequence=i + ID_OFFSET)

        # Validar reglas
        is_valid, violations = validate_employee(emp)
        if not is_valid:
            n_invalid += 1
            for v in violations:
                rule = v.split(":")[0]
                violations_by_rule[rule] = violations_by_rule.get(rule, 0) + 1

        # Serializar fechas para MongoDB
        emp_serialized = _serialize_dates(emp)
        batch.append(emp_serialized)

        # Guardar para validacion R14 (cross-record)
        all_employees_for_validation.append(emp)

        # Insertar en batches
        if len(batch) >= BATCH_SIZE:
            sink.insert_batch(batch)
            batch.clear()

        # Logging de progreso
        if i % LOG_PROGRESS_EVERY == 0:
            elapsed = time.time() - start
            rate = i / elapsed if elapsed > 0 else 0
            logger.info(f"  Progreso: {i}/{N_OUTPUTS} ({rate:.1f} empleados/s)")

    # Insertar el ultimo batch
    if batch:
        sink.insert_batch(batch)

    # Validacion R14 cross-record
    ok_r14, msg_r14 = validate_name_diversity(all_employees_for_validation)
    if ok_r14:
        logger.info(msg_r14)
    else:
        logger.warning(msg_r14)

    elapsed = time.time() - start
    logger.info("=" * 60)
    logger.info(f"GENERACION COMPLETADA en {elapsed:.1f}s")
    logger.info(f"  Total insertados: {sink.count()}")
    logger.info(f"  Empleados con violaciones: {n_invalid} ({100*n_invalid/N_OUTPUTS:.2f}%)")
    if violations_by_rule:
        logger.info("  Violaciones por regla:")
        for rule, count in sorted(violations_by_rule.items()):
            logger.info(f"    {rule}: {count}")
    logger.info("=" * 60)

    sink.close()


if __name__ == "__main__":
    run()
