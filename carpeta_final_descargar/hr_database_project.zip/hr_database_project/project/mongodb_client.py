"""
mongodb_client.py
=================
Cliente de MongoDB. Si pymongo no esta instalado o no se puede conectar,
se hace fallback a guardar los registros en JSONL.

CONEXION CONFIGURADA:
- Host: 10.0.64.11 (VM Linux)
- Puerto: 27017
- Para sobrescribir: export MONGO_URI="mongodb://otro_host:27017"
"""

import os
import json
import logging
import datetime as dt
from pathlib import Path
from config import MONGO_DB_NAME, MONGO_COLLECTION, PROJECT_ROOT

logger = logging.getLogger(__name__)

# URI por defecto: VM Linux. Si se define la variable de entorno MONGO_URI, se usa esa.
DEFAULT_MONGO_URI = "mongodb://10.0.64.11:27017"
MONGO_URI = os.getenv("MONGO_URI", DEFAULT_MONGO_URI)


def _json_default(obj):
    """Serializador JSON para tipos no nativos (datetime, date)."""
    if isinstance(obj, (dt.datetime, dt.date)):
        return obj.isoformat()
    raise TypeError(f"Tipo no serializable: {type(obj)}")


class MongoSink:
    """Sink que inserta en MongoDB."""

    def __init__(self):
        from pymongo import MongoClient, ASCENDING
        self.client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)
        # Verificar conexion
        self.client.admin.command("ping")
        self.db = self.client[MONGO_DB_NAME]
        self.collection = self.db[MONGO_COLLECTION]
        # Limpiar coleccion para empezar de cero 
        # no queremos limpiar para paralelizarlo en las maquinas
        #self.collection.drop()
        # Crear indices
        self.collection.create_index([("profile.employee_id", ASCENDING)], unique=True)
        self.collection.create_index([("profile.country", ASCENDING)])
        self.collection.create_index([("employment.department", ASCENDING)])
        self.collection.create_index([("employment.hire_date", ASCENDING)])
        logger.info(f"Conectado a MongoDB: {MONGO_URI} / DB: {MONGO_DB_NAME} / Col: {MONGO_COLLECTION}")

    def insert_batch(self, docs: list[dict]):
        if docs:
            self.collection.insert_many(docs, ordered=False)

    def count(self) -> int:
        return self.collection.count_documents({})

    def close(self):
        self.client.close()


class JsonlSink:
    """Sink de respaldo que escribe registros en un archivo JSONL."""

    def __init__(self):
        self.path = PROJECT_ROOT / "output_employees.jsonl"
        # Vaciar el archivo
        self.path.write_text("", encoding="utf-8")
        self.file = open(self.path, "a", encoding="utf-8")
        self._count = 0
        logger.warning(f"MongoDB no disponible. Escribiendo en {self.path}")

    def insert_batch(self, docs: list[dict]):
        for d in docs:
            self.file.write(json.dumps(d, default=_json_default, ensure_ascii=False) + "\n")
        self._count += len(docs)

    def count(self) -> int:
        return self._count

    def close(self):
        self.file.close()


def get_sink():
    """Devuelve el sink disponible (MongoDB o JSONL como fallback)."""
    try:
        return MongoSink()
    except Exception as e:
        logger.warning(f"No se pudo conectar a MongoDB en {MONGO_URI} ({e.__class__.__name__}: {e})")
        return JsonlSink()