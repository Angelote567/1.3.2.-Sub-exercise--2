"""
coherence_rules.py
==================
Implementa las 18 reglas de coherencia del PDF (R01-R18).
Cada regla devuelve True si se cumple, False si se viola.
"""

import datetime as dt
from helpers import years_between, months_between
from config import MIN_AGE_AT_HIRE


def _to_date(d):
    """Normaliza datetime/date a date."""
    if d is None:
        return None
    if isinstance(d, dt.datetime):
        return d.date()
    return d


def validate_employee(emp: dict) -> tuple[bool, list[str]]:
    """
    Valida un empleado completo contra las 18 reglas.
    Devuelve (is_valid, list_of_violations).
    """
    violations = []
    profile = emp.get("profile", {})
    employment = emp.get("employment", {})
    compensation = emp.get("compensation", {})
    osh = emp.get("osh", {})
    ss = emp.get("social_security", {})
    resources = emp.get("resources", {})
    exit_b = emp.get("exit", {})

    birth_date = _to_date(profile.get("birth_date"))
    hire_date = _to_date(employment.get("hire_date"))
    ss_enrollment_date = _to_date(ss.get("ss_enrollment_date"))
    termination_date = _to_date(exit_b.get("termination_date"))
    osh_training_date = _to_date(osh.get("osh_training_date"))
    asset_return_date = _to_date(resources.get("asset_return_date"))

    # R01: Edad minima al contratar
    if birth_date and hire_date:
        age_at_hire = years_between(birth_date, hire_date)
        if age_at_hire < MIN_AGE_AT_HIRE:
            violations.append(f"R01: edad al contratar ({age_at_hire}) < {MIN_AGE_AT_HIRE}")

    # R02: Edad realista (18-67)
    if birth_date:
        age = years_between(birth_date, dt.date.today())
        if age < 18 or age > 67:
            violations.append(f"R02: edad fuera de rango ({age})")

    # R03: ss_enrollment_date >= hire_date
    if hire_date and ss_enrollment_date:
        if ss_enrollment_date < hire_date:
            violations.append("R03: ss_enrollment_date < hire_date")

    # R04: termination_date >= hire_date
    if hire_date and termination_date:
        if termination_date < hire_date:
            violations.append("R04: termination_date < hire_date")

    # R05: probation <= duracion del empleo
    if hire_date:
        end = termination_date if termination_date else dt.date.today()
        months_employed = months_between(hire_date, end)
        prob = employment.get("probation_period", 0)
        if prob > months_employed and months_employed > 0:
            violations.append(f"R05: probation ({prob}) > meses empleado ({months_employed})")

    # R06: salario en rango (no validamos exactamente porque el rango ya se aplico en generacion)
    if compensation.get("base_salary_monthly", 0) <= 0:
        violations.append("R06: base_salary_monthly <= 0")

    # R07: currency coincide con pais
    # (validacion implicita: el CSV ya empareja country->currency)

    # R08: IBAN comienza con codigo de pais (solo paises EU)
    iban = compensation.get("bank_account_iban", "")
    country = profile.get("country", "")
    eu_iban_countries = {"ES","DE","FR","GB","IT","PT","NL","BE","PL","CH","IE"}
    if country in eu_iban_countries and iban:
        if not iban.startswith(country):
            violations.append(f"R08: IBAN no empieza con {country}")

    # R09: postal code coherente con city/country
    # (validacion implicita: el CSV cities ya empareja postal_code con city/country)

    # R10: si termination_date es None, exit fields vacios
    if not termination_date:
        if exit_b.get("termination_reason") is not None:
            violations.append("R10: termination_reason no es None pero termination_date si")
        if exit_b.get("severance_delivered"):
            violations.append("R10: severance_delivered=True pero termination_date=None")

    # R11: si termination_date existe, exit_b completos
    if termination_date:
        if not exit_b.get("termination_reason"):
            violations.append("R11: termination_date existe pero termination_reason esta vacio")

    # R12: nombre consistente (siempre el mismo en todo el documento)
    # (validacion implicita: solo se genera una vez)

    # R13: email contiene first_name + last_name
    email = profile.get("email", "")
    fn = profile.get("first_name", "").lower().split()[0] if profile.get("first_name") else ""
    if fn and email:
        # eliminar tildes para la comparacion
        import unicodedata
        fn_norm = unicodedata.normalize('NFD', fn).encode('ascii','ignore').decode('ascii')
        if fn_norm not in email.lower():
            violations.append(f"R13: email no contiene first_name ({fn_norm})")

    # R14: name diversity - se valida al final del pipeline (cross-record)

    # R15: si single, dependents tiende a 0
    # (validacion suave, no falla aunque sea !=0)

    # R16: osh_training_date >= hire_date
    if hire_date and osh_training_date:
        if osh_training_date < hire_date:
            violations.append("R16: osh_training_date < hire_date")

    # R17: asset_return_date solo si termination_date existe
    if asset_return_date and not termination_date:
        violations.append("R17: asset_return_date sin termination_date")

    # R18: withholding_rate dentro de rangos legales
    wh = compensation.get("withholding_rate", 0)
    if wh < 0 or wh > 0.50:
        violations.append(f"R18: withholding_rate ({wh}) fuera de rango")

    return (len(violations) == 0, violations)


def validate_name_diversity(employees: list[dict], threshold: float = 0.0001) -> tuple[bool, str]:
    """
    R14: ningun par first+last name aparece en mas del threshold (0.01%) del dataset.
    Solo se evalua cross-record, al final del pipeline.
    """
    from collections import Counter
    name_counter = Counter()
    for emp in employees:
        p = emp.get("profile", {})
        key = f"{p.get('first_name','')}|{p.get('last_name','')}"
        name_counter[key] += 1

    total = len(employees)
    max_allowed = max(2, int(total * threshold))
    violators = [(name, c) for name, c in name_counter.items() if c > max_allowed]

    if violators:
        msg = f"R14: {len(violators)} combinaciones de nombre+apellido superan el {threshold*100}%"
        return (False, msg)
    return (True, "R14 OK")
