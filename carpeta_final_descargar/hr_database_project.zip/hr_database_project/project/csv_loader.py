"""
csv_loader.py
=============
Carga todos los CSVs de data/csvs/ una sola vez en memoria.
Devuelve un dict con todos los datos accesibles por nombre.
"""

import csv
import logging
from pathlib import Path
from config import CSV_DIR

logger = logging.getLogger(__name__)


def _load_csv(filename: str) -> list[dict]:
    """Carga un CSV como lista de dicts."""
    path = CSV_DIR / filename
    if not path.exists():
        raise FileNotFoundError(f"No existe el CSV: {path}")
    with open(path, encoding="utf-8") as f:
        return list(csv.DictReader(f))


def load_all_csvs() -> dict:
    """
    Carga todos los CSVs y los devuelve en un dict accesible por nombre.

    Returns:
        dict con claves = nombre del CSV (sin extension) y valores = list[dict]
    """
    logger.info(f"Cargando CSVs desde {CSV_DIR}")

    files = [
        "countries.csv",
        "cities.csv",
        "departments.csv",
        "first_names.csv",
        "last_names.csv",
        "gender.csv",
        "marital_status.csv",
        "contract_type.csv",
        "workday.csv",
        "schedules.csv",
        "medical_fitness.csv",
        "contribution_group.csv",
        "applicable_bonuses.csv",
        "ppe_details.csv",
        "termination_reasons.csv",
        "documentation_probabilities.csv",
        "osh_probabilities.csv",
        "resources_probabilities.csv",
        "system_accesses.csv",
        "assigned_licenses.csv",
        "salary_ranges.csv",
        "job_titles.csv",
        "work_centers.csv",
        "role_risk_factors.csv",
        "job_groups.csv",
        "collective_agreements.csv",
        "other_assets.csv",
        "degrees_certificates.csv",
        "history_events.csv",
        "contract_addenda.csv",
        "note_templates.csv",
    ]

    data = {}
    for fname in files:
        key = fname.replace(".csv", "")
        data[key] = _load_csv(fname)
        logger.debug(f"  {key}: {len(data[key])} filas")

    logger.info(f"Cargados {len(data)} CSVs correctamente")
    return data
