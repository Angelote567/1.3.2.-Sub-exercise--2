"""
generators/osh.py
=================
Genera el bloque OSH (Occupational Safety and Health / PRL).
"""

import random
import datetime as dt
from helpers import (
    weighted_choice, weighted_bool, filter_rows,
    random_date_between,
)


def generate_osh(csvs: dict, employment: dict) -> dict:
    """
    Genera bloque PRL. Aplica:
    - R16: osh_training_date >= hire_date
    """
    department = employment["department"]
    hire_date = employment["hire_date"]

    # --- Factor de riesgo segun departamento ---
    risk_pool = filter_rows(csvs["role_risk_factors"], department=department)
    if risk_pool:
        role_risk_factors = weighted_choice(risk_pool, "weight", "role_risk_factors")
    else:
        role_risk_factors = "Office"

    # --- Pesos OSH boolean ---
    osh_probs = {
        r["field"]: (float(r["true_weight"]), float(r["false_weight"]))
        for r in csvs["osh_probabilities"]
    }
    tw, fw = osh_probs.get("osh_training_received", (97, 3))
    osh_training_received = weighted_bool(tw, fw)

    # Fecha formacion PRL (R16): >= hire_date
    if osh_training_received:
        max_date = dt.date.today()
        if max_date < hire_date:
            max_date = hire_date
        osh_training_date = random_date_between(hire_date, max_date)
    else:
        osh_training_date = None

    # --- EPIs (mas comunes en perfiles industriales/field) ---
    if role_risk_factors in ("Industrial", "Field"):
        ppe_issued = weighted_bool(80, 20)
    else:
        tw, fw = osh_probs.get("ppe_issued", (25, 75))
        ppe_issued = weighted_bool(tw, fw)

    if ppe_issued:
        ppe_details = weighted_choice(csvs["ppe_details"], "weight", "ppe_details")
    else:
        ppe_details = None

    # --- Aptitud medica ---
    medical_fitness = weighted_choice(csvs["medical_fitness"], "weight", "medical_fitness")

    # --- Fecha del ultimo examen medico ---
    if medical_fitness != "Pending review":
        max_date = dt.date.today()
        if max_date < hire_date:
            max_date = hire_date
        medical_exam_date = random_date_between(hire_date, max_date)
    else:
        medical_exam_date = None

    # --- Notas (10-15% segun PDF) ---
    osh_notes = None
    if random.random() < 0.12:
        notes_pool = filter_rows(csvs["note_templates"], note_type="osh_notes")
        if notes_pool:
            osh_notes = weighted_choice(notes_pool, "weight", "note_text")

    return {
        "role_risk_factors": role_risk_factors,
        "osh_training_received": osh_training_received,
        "osh_training_date": osh_training_date,
        "ppe_issued": ppe_issued,
        "ppe_details": ppe_details,
        "medical_fitness": medical_fitness,
        "medical_exam_date": medical_exam_date,
        "osh_notes": osh_notes,
    }
