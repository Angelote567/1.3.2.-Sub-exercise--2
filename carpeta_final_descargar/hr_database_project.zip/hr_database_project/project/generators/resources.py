"""
generators/resources.py
=======================
Genera el bloque Assigned Resources.
"""

import random
import datetime as dt
from helpers import (
    weighted_bool, filter_rows, random_date_between,
)


def generate_resources(csvs: dict, employment: dict, exit_block: dict) -> dict:
    """
    Genera bloque de recursos asignados. Aplica:
    - R17: asset_return_date solo si termination_date existe
    """
    department = employment["department"]
    hire_date = employment["hire_date"]
    termination_date = exit_block.get("termination_date")

    # --- Booleans de recursos basicos ---
    res_probs = {
        r["field"]: (float(r["true_weight"]), float(r["false_weight"]))
        for r in csvs["resources_probabilities"]
    }
    tw, fw = res_probs.get("laptop_assigned", (68.4, 31.6))
    laptop_assigned = weighted_bool(tw, fw)
    tw, fw = res_probs.get("mobile_phone_assigned", (80, 20))
    mobile_phone_assigned = weighted_bool(tw, fw)
    tw, fw = res_probs.get("access_card_assigned", (95, 5))
    access_card_assigned = weighted_bool(tw, fw)

    # --- Other assets (lista, filtrada por departamento) ---
    asset_pool = [
        a for a in csvs["other_assets"]
        if a["department_match"] == department or a["department_match"] == "All"
    ]
    other_assets = []
    seen = set()
    for asset in asset_pool:
        # Cada asset tiene su propio peso de uso
        if random.random() * 100 < float(asset["usage_weight"]):
            name = asset["asset"]
            if name not in seen:
                other_assets.append(name)
                seen.add(name)
    # Limitar a 5 maximo para no explotar el documento
    if len(other_assets) > 5:
        other_assets = random.sample(other_assets, 5)

    # --- Fechas de entrega/devolucion ---
    # Fecha entrega: poco despues de la contratacion
    asset_delivery_date = hire_date + dt.timedelta(days=random.randint(0, 14))

    # R17: asset_return_date solo si esta terminado
    if termination_date:
        if isinstance(termination_date, dt.datetime):
            termination_date = termination_date.date()
        # Devolucion entre el dia de termination y 7 dias despues
        asset_return_date = termination_date + dt.timedelta(days=random.randint(0, 7))
    else:
        asset_return_date = None

    # --- Accesos a sistemas (lista filtrada por uso) ---
    system_accesses = []
    for sys_row in csvs["system_accesses"]:
        if random.random() * 100 < float(sys_row["usage_weight"]):
            system_accesses.append(sys_row["system_access"])

    # --- Licencias asignadas (lista filtrada por uso) ---
    assigned_licenses = []
    for lic_row in csvs["assigned_licenses"]:
        if random.random() * 100 < float(lic_row["usage_weight"]):
            assigned_licenses.append(lic_row["license"])

    return {
        "laptop_assigned": laptop_assigned,
        "mobile_phone_assigned": mobile_phone_assigned,
        "access_card_assigned": access_card_assigned,
        "other_assets": other_assets,
        "asset_delivery_date": asset_delivery_date,
        "asset_return_date": asset_return_date,
        "system_accesses": system_accesses,
        "assigned_licenses": assigned_licenses,
    }
