"""
generators/history.py
=====================
Genera el bloque History (lista de eventos historicos del empleado).
"""

import random
import datetime as dt
from helpers import random_date_between, filter_rows


def generate_history(csvs: dict, employment: dict, exit_block: dict) -> list[dict]:
    """
    Genera la lista de eventos historicos del empleado, ordenada cronologicamente.
    Recibe exit_block para saber si esta terminado y cuando.
    """
    hire_date = employment["hire_date"]
    termination_date = exit_block.get("termination_date")
    end_date = termination_date if termination_date else dt.date.today()

    if isinstance(end_date, dt.datetime):
        end_date = end_date.date()

    events = []

    # 1) Hiring (siempre primero)
    events.append({
        "date": hire_date,
        "event_type": "Hiring",
        "status": "completed",
        "description": "Initial hiring of the employee",
    })

    # 2) Onboarding (1-2 semanas despues)
    onb_date = hire_date + dt.timedelta(days=random.randint(7, 21))
    if onb_date <= end_date:
        events.append({
            "date": onb_date,
            "event_type": "Onboarding completed",
            "status": "completed",
            "description": "Onboarding process finalized",
        })

    # 3) Equipment delivery (primer mes)
    eq_date = hire_date + dt.timedelta(days=random.randint(0, 30))
    if eq_date <= end_date:
        events.append({
            "date": eq_date,
            "event_type": "Equipment delivery",
            "status": "completed",
            "description": "Company equipment delivered",
        })

    # 4) Probation period passed
    prob_months = employment["probation_period"]
    prob_date = hire_date + dt.timedelta(days=prob_months * 30)
    if prob_date <= end_date:
        events.append({
            "date": prob_date,
            "event_type": "Probation period passed",
            "status": "completed",
            "description": "Probation period successfully completed",
        })

    # 5) Eventos anuales (vacaciones, performance review)
    months_employed = (end_date.year - hire_date.year) * 12 + end_date.month - hire_date.month
    years_employed = months_employed // 12

    for year_idx in range(years_employed):
        year_start = hire_date + dt.timedelta(days=365 * (year_idx + 1) - 200)
        year_end = hire_date + dt.timedelta(days=365 * (year_idx + 1))
        if year_end > end_date:
            year_end = end_date

        # Performance review anual (80%)
        if random.random() < 0.80 and year_start < year_end:
            events.append({
                "date": random_date_between(year_start, year_end),
                "event_type": "Annual performance review",
                "status": "completed",
                "description": "Annual performance review",
            })

        # Vacaciones (80%)
        if random.random() < 0.80 and year_start < year_end:
            events.append({
                "date": random_date_between(year_start, year_end),
                "event_type": "Vacation period",
                "status": "completed",
                "description": "Annual vacation taken",
            })

        # Ajuste salarial (40%)
        if random.random() < 0.40 and year_start < year_end:
            events.append({
                "date": random_date_between(year_start, year_end),
                "event_type": "Salary adjustment",
                "status": "completed",
                "description": "Salary review and adjustment",
            })

        # OSH training anual (70%)
        if random.random() < 0.70 and year_start < year_end:
            events.append({
                "date": random_date_between(year_start, year_end),
                "event_type": "OSH training",
                "status": "completed",
                "description": "Occupational safety training completed",
            })

    # 6) Eventos raros
    if years_employed >= 2 and random.random() < 0.20:
        events.append({
            "date": random_date_between(
                hire_date + dt.timedelta(days=730), end_date),
            "event_type": "Promotion",
            "status": "completed",
            "description": "Promoted to a higher position",
        })

    # 7) Si esta terminado, anadir eventos de salida
    if termination_date:
        if isinstance(termination_date, dt.datetime):
            termination_date = termination_date.date()
        events.append({
            "date": termination_date,
            "event_type": "Termination",
            "status": "completed",
            "description": "Employment terminated",
        })
        if exit_block.get("exit_interview_done"):
            events.append({
                "date": termination_date,
                "event_type": "Exit interview",
                "status": "completed",
                "description": "Exit interview conducted",
            })

    # Ordenar cronologicamente
    events.sort(key=lambda e: e["date"])
    return events
