"""
generators/documentation.py
===========================
Genera el bloque Documentation.
"""

import random
import datetime as dt
from helpers import (
    weighted_bool, weighted_choice, filter_rows,
    random_date_between,
)


def generate_documentation(csvs: dict, profile: dict, employment: dict) -> dict:
    """
    Genera el bloque de documentacion. Cada campo booleano usa los pesos
    de documentation_probabilities.csv.
    """
    # Cargar pesos en un dict {field: (true_w, false_w)}
    probs = {
        r["field"]: (float(r["true_weight"]), float(r["false_weight"]))
        for r in csvs["documentation_probabilities"]
    }

    def _b(field):
        tw, fw = probs.get(field, (100, 0))
        return weighted_bool(tw, fw)

    # --- Booleans ---
    contract_signed = _b("contract_signed")
    id_copy = _b("id_copy")
    resume_cv = _b("resume_cv")
    gdpr_policies_signed = _b("gdpr_policies_signed")
    code_of_ethics_signed = _b("code_of_ethics_signed")
    osh_informed = _b("osh_informed")
    image_use_authorization = _b("image_use_authorization")
    medical_clearance = _b("medical_clearance")

    # --- Adendas contractuales (lista, normalmente pequena) ---
    contract_addenda = []
    n_addenda = random.choices([0, 1, 2, 3], weights=[60, 25, 10, 5], k=1)[0]
    addenda_pool = csvs["contract_addenda"]
    seen = set()
    for _ in range(n_addenda):
        chosen = weighted_choice(addenda_pool, "weight", "contract_addendum")
        if chosen and chosen not in seen:
            contract_addenda.append(chosen)
            seen.add(chosen)

    # --- Titulos / certificaciones (coherente con seniority) ---
    seniority = employment["_seniority_level"]
    deg_pool = [
        d for d in csvs["degrees_certificates"]
        if d["seniority_match"] == "All" or seniority in d["seniority_match"].split(",")
    ]
    if not deg_pool:
        deg_pool = csvs["degrees_certificates"]

    # Numero de titulaciones segun seniority
    n_degrees = {
        "Entry":    random.choices([0,1,2], weights=[20,60,20], k=1)[0],
        "Mid":      random.choices([1,2,3], weights=[40,40,20], k=1)[0],
        "Senior":   random.choices([1,2,3,4], weights=[20,40,30,10], k=1)[0],
        "Manager":  random.choices([2,3,4], weights=[30,50,20], k=1)[0],
        "Director": random.choices([2,3,4,5], weights=[20,40,30,10], k=1)[0],
    }.get(seniority, 1)

    degrees_certificates = []
    seen = set()
    attempts = 0
    while len(degrees_certificates) < n_degrees and attempts < 20:
        chosen = weighted_choice(deg_pool, "weight", "degree_certificate")
        if chosen and chosen not in seen:
            degrees_certificates.append(chosen)
            seen.add(chosen)
        attempts += 1

    # --- Fecha de la ultima actualizacion documental ---
    hire_date = employment["hire_date"]
    last_doc_update_date = random_date_between(hire_date, dt.date.today())

    return {
        "contract_signed": contract_signed,
        "contract_addenda": contract_addenda,
        "id_copy": id_copy,
        "degrees_certificates": degrees_certificates,
        "resume_cv": resume_cv,
        "gdpr_policies_signed": gdpr_policies_signed,
        "code_of_ethics_signed": code_of_ethics_signed,
        "osh_informed": osh_informed,
        "medical_clearance": medical_clearance,
        "image_use_authorization": image_use_authorization,
        "last_doc_update_date": last_doc_update_date,
    }
