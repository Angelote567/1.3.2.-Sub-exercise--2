"""
generators/exit_process.py
==========================
Genera el bloque Exit Process.
"""

import random
import datetime as dt
from helpers import (
    weighted_choice, weighted_bool, filter_rows,
    random_date_between,
)
from config import TERMINATION_PROBABILITY, REFERENCE_DATE


def generate_exit(csvs: dict, employment: dict) -> dict:
    """
    Genera bloque Exit. Aplica:
    - R04: termination_date >= hire_date
    - R10: si termination_date=None, todos los campos = False/None
    - R11: si termination_date existe, los campos estan completos
    """
    hire_date = employment["hire_date"]

    # Decidir si esta terminado
    is_terminated = random.random() < TERMINATION_PROBABILITY

    if not is_terminated:
        # R10: todos los campos vacios/falsos
        return {
            "termination_date": None,
            "termination_reason": None,
            "exit_interview_done": False,
            "severance_delivered": False,
            "employer_certificate_delivered": False,
            "assets_recovered": False,
            "exit_comments": None,
        }

    # R04: termination_date >= hire_date (al menos 1 mes despues)
    earliest_termination = hire_date + dt.timedelta(days=30)
    latest_termination = REFERENCE_DATE
    if earliest_termination > latest_termination:
        # No se puede terminar todavia, lo dejamos activo
        return {
            "termination_date": None,
            "termination_reason": None,
            "exit_interview_done": False,
            "severance_delivered": False,
            "employer_certificate_delivered": False,
            "assets_recovered": False,
            "exit_comments": None,
        }

    termination_date = random_date_between(earliest_termination, latest_termination)

    # R11: campos completos
    termination_reason = weighted_choice(
        csvs["termination_reasons"], "weight", "termination_reason"
    )

    # Exit interview (60-80% en resignations voluntarias)
    if termination_reason == "Voluntary Resignation":
        exit_interview_done = weighted_bool(70, 30)
    else:
        exit_interview_done = weighted_bool(40, 60)

    # Severance solo en algunos casos
    if termination_reason in ("Dismissal", "Layoff", "Mutual Agreement"):
        severance_delivered = weighted_bool(85, 15)
    else:
        severance_delivered = weighted_bool(20, 80)

    employer_certificate_delivered = weighted_bool(95, 5)
    assets_recovered = weighted_bool(90, 10)

    # Comentarios (40% de los casos)
    exit_comments = None
    if random.random() < 0.40:
        notes_pool = filter_rows(csvs["note_templates"], note_type="exit_comments")
        if notes_pool:
            exit_comments = weighted_choice(notes_pool, "weight", "note_text")

    return {
        "termination_date": termination_date,
        "termination_reason": termination_reason,
        "exit_interview_done": exit_interview_done,
        "severance_delivered": severance_delivered,
        "employer_certificate_delivered": employer_certificate_delivered,
        "assets_recovered": assets_recovered,
        "exit_comments": exit_comments,
    }
