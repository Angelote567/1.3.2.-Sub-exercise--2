"""
generators/profile.py
=====================
Genera el bloque EmployeeProfile.
"""

import random
from helpers import (
    weighted_choice, filter_rows,
    random_birth_date, generate_id_document,
    generate_phone, generate_email, generate_address,
)
from config import REFERENCE_DATE, MIN_AGE_AT_HIRE, MAX_AGE_ACTIVE


def generate_profile(csvs: dict, employee_id: str, work_center: dict) -> dict:
    """
    Genera un EmployeeProfile coherente:
    - country viene del work_center (decision previa en el pipeline)
    - city, province, postal_code coherentes con country (R09)
    - first_name + gender + last_name coherentes con country (R12, R13)
    """
    country_iso = work_center["country_iso"]

    # --- Genero ---
    gender = weighted_choice(csvs["gender"], "weight", "gender")

    # --- Nombre ---
    # Si el genero es Non-binary o Prefer not to say, escogemos M o F aleatorio para el pool
    name_gender = gender if gender in ("Male", "Female") else random.choice(["Male", "Female"])
    name_candidates = filter_rows(csvs["first_names"],
                                  country_iso=country_iso, gender=name_gender)
    if not name_candidates:
        # Fallback a Espana si el pais no tiene pool
        name_candidates = filter_rows(csvs["first_names"],
                                      country_iso="ES", gender=name_gender)
    first_name = weighted_choice(name_candidates, "weight", "name")

    # --- Apellidos ---
    surname_pool = filter_rows(csvs["last_names"], country_iso=country_iso)
    if not surname_pool:
        surname_pool = filter_rows(csvs["last_names"], country_iso="ES")

    from config import HISPANIC_COUNTRIES
    if country_iso in HISPANIC_COUNTRIES:
        # Dos apellidos
        s1 = weighted_choice(surname_pool, "weight", "surname")
        s2 = weighted_choice(surname_pool, "weight", "surname")
        last_name = f"{s1} {s2}"
    else:
        last_name = weighted_choice(surname_pool, "weight", "surname")

    # --- Fecha de nacimiento (R02) ---
    birth_date = random_birth_date(MIN_AGE_AT_HIRE, MAX_AGE_ACTIVE, REFERENCE_DATE)

    # --- Documento identidad ---
    id_document = generate_id_document(country_iso)

    # --- Nacionalidad ---
    # 90% misma que country, 10% otra
    if random.random() < 0.9:
        nationality = country_iso
    else:
        other_country = weighted_choice(csvs["countries"], "weight", "iso_code")
        nationality = other_country

    # --- Geografia (city/province/postal_code coherentes - R09) ---
    cities_in_country = filter_rows(csvs["cities"], country_iso=country_iso)
    # Preferimos la ciudad del work_center si esta disponible
    cities_in_wc = [c for c in cities_in_country if c["city"] == work_center["city"]]
    pool = cities_in_wc if cities_in_wc else cities_in_country
    chosen_city = random.choice(pool) if pool else None

    if chosen_city:
        city = chosen_city["city"]
        province = chosen_city["province"]
        postal_code = chosen_city["postal_code"]
    else:
        city, province, postal_code = work_center["city"], "", ""

    # --- Estado civil ---
    marital_status = weighted_choice(csvs["marital_status"], "weight", "marital_status")

    # --- Dependientes (R15) ---
    if marital_status in ("Single", "Divorced", "Widowed"):
        dependents = random.choices([0,1,2,3], weights=[70,15,10,5], k=1)[0]
    else:  # Married, Domestic partnership
        dependents = random.choices([0,1,2,3,4], weights=[20,30,30,15,5], k=1)[0]

    # --- Telefono y email ---
    phone = generate_phone(country_iso)
    email = generate_email(first_name, last_name)

    # --- Direccion ---
    address = generate_address(city)

    return {
        "employee_id": employee_id,
        "first_name": first_name,
        "last_name": last_name,
        "gender": gender,
        "id_document": id_document,
        "birth_date": birth_date,
        "nationality": nationality,
        "address": address,
        "city": city,
        "country": country_iso,
        "province": province,
        "postal_code": postal_code,
        "phone": phone,
        "email": email,
        "marital_status": marital_status,
        "dependents": dependents,
    }
