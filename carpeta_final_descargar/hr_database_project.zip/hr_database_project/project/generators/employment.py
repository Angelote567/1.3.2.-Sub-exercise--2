"""
generators/employment.py
========================
Genera el bloque Employment Information.
"""

import random
import datetime as dt
from helpers import (
    weighted_choice, filter_rows,
    random_date_between, years_between,
)
from config import (
    REFERENCE_DATE, MIN_HIRE_YEAR, MAX_HIRE_YEAR,
    MIN_AGE_AT_HIRE,
)


def generate_employment(csvs: dict, profile: dict, work_center: dict,
                        termination_date=None) -> dict:
    """
    Genera Employment Information.
    Recibe profile (para validar edad vs hire_date - R01), work_center,
    y opcionalmente termination_date para ajustar probation_period (R05).
    """
    country_iso = profile["country"]
    birth_date = profile["birth_date"]

    # --- Departamento ---
    department = weighted_choice(csvs["departments"], "weight", "department")

    # --- Job title coherente con departamento ---
    titles_in_dept = filter_rows(csvs["job_titles"], department=department)
    chosen_title = weighted_choice(titles_in_dept, "weight")
    job_title = chosen_title["job_title"]
    seniority_level = chosen_title["seniority_level"]

    # --- Job group (categoria de cotizacion, coherente con seniority) ---
    job_groups_matching = [
        g for g in csvs["job_groups"]
        if seniority_level in g["seniority_match"].split(",")
    ]
    if not job_groups_matching:
        job_groups_matching = csvs["job_groups"]
    job_group = weighted_choice(job_groups_matching, "weight", "job_group")

    # --- Hire date (R01: edad >= MIN_AGE_AT_HIRE en hire_date) ---
    # Ignoramos anos bisiestos (365 dias/ano) para evitar casos limite con 29-feb
    earliest_hire = max(
        dt.date(MIN_HIRE_YEAR, 1, 1),
        birth_date + dt.timedelta(days=MIN_AGE_AT_HIRE * 365),
    )
    latest_hire = REFERENCE_DATE
    if earliest_hire > latest_hire:
        # Empleado demasiado joven, ajustar
        earliest_hire = latest_hire - dt.timedelta(days=30)
    hire_date = random_date_between(earliest_hire, latest_hire)

    # --- Tipo de contrato ---
    contract_type = weighted_choice(csvs["contract_type"], "weight", "contract_type")

    # --- Jornada ---
    workday = weighted_choice(csvs["workday"], "weight", "workday")

    # --- Schedule coherente con workday ---
    sched_pool = filter_rows(csvs["schedules"], workday_type=workday)
    schedule = weighted_choice(sched_pool, "weight", "schedule") if sched_pool else "9-18"

    # --- Periodo de prueba (en meses, coherente con duracion del empleo) ---
    # R05: probation_period <= meses_empleado (hasta termination o hasta hoy)
    end_date = termination_date if termination_date else REFERENCE_DATE
    months_employed = (end_date - hire_date).days // 30
    if contract_type == "Internship":
        candidate = random.choice([1, 2, 3])
    elif contract_type == "Temporary":
        candidate = random.choice([1, 2])
    else:  # Permanent, Project-based
        candidate = random.choice([3, 6])
    probation_period = min(candidate, months_employed) if months_employed > 0 else 0

    # --- Convenio colectivo ---
    agreements_country = filter_rows(csvs["collective_agreements"], country_iso=country_iso)
    if agreements_country:
        applicable_collective_agreement = weighted_choice(
            agreements_country, "weight", "collective_agreement"
        )
    else:
        applicable_collective_agreement = "General Labor Agreement"

    return {
        "job_title": job_title,
        "department": department,
        "work_center": work_center["work_center_code"],
        "job_group": job_group,
        "hire_date": hire_date,
        "contract_type": contract_type,
        "workday": workday,
        "schedule": schedule,
        "probation_period": probation_period,
        "applicable_collective_agreement": applicable_collective_agreement,
        # campos auxiliares para otros generadores (no se serializan tal cual)
        "_seniority_level": seniority_level,
    }
