"""
generators/social_security.py
=============================
Genera el bloque Social Security.
"""

import random
import datetime as dt
from helpers import (
    weighted_choice, weighted_bool, filter_rows,
    random_date_between, generate_ss_number, years_between,
)
from config import REFERENCE_DATE


def generate_social_security(csvs: dict, profile: dict, employment: dict) -> dict:
    """
    Genera bloque Seguridad Social. Aplica:
    - R03: ss_enrollment_date >= hire_date
    - applicable_bonuses depende de la edad (Youth Employment <= 30 anos)
    """
    country_iso = profile["country"]
    hire_date = employment["hire_date"]
    birth_date = profile["birth_date"]
    age = years_between(birth_date, REFERENCE_DATE)

    # --- Numero de afiliacion ---
    ss_affiliation_number = generate_ss_number(country_iso)

    # --- Fecha de alta SS (R03: >= hire_date) ---
    # Generalmente se da de alta el mismo dia o muy poco despues
    days_offset = random.choices([0, 1, 2, 3, 7], weights=[60, 20, 10, 5, 5], k=1)[0]
    ss_enrollment_date = hire_date + dt.timedelta(days=days_offset)

    # --- Grupo de cotizacion (coherente con seniority) ---
    seniority = employment["_seniority_level"]
    cg_pool = csvs["contribution_group"]
    contribution_group = weighted_choice(cg_pool, "weight", "contribution_group")

    # --- Tipo de retencion SS (4-8% segun PDF) ---
    withholding_rate_ss = round(random.uniform(0.04, 0.08), 4)

    # --- Bonificaciones aplicables ---
    bonus_pool = csvs["applicable_bonuses"]

    # Filtrar bonificaciones segun edad
    valid_bonuses = []
    for b in bonus_pool:
        name = b["applicable_bonus"]
        # Youth Employment Bonus: solo si edad <= 30
        if name == "Youth Employment Bonus" and age > 30:
            continue
        valid_bonuses.append(b)

    chosen_bonus = weighted_choice(valid_bonuses, "weight", "applicable_bonus")
    if chosen_bonus and chosen_bonus != "No bonus":
        applicable_bonuses = [chosen_bonus]
    else:
        applicable_bonuses = []

    return {
        "ss_affiliation_number": ss_affiliation_number,
        "ss_enrollment_date": ss_enrollment_date,
        "contribution_group": contribution_group,
        "withholding_rate_ss": withholding_rate_ss,
        "applicable_bonuses": applicable_bonuses,
    }
