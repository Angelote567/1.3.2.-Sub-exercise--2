"""
generators/compensation.py
==========================
Genera el bloque Compensation.
"""

import random
from helpers import filter_rows, generate_iban
from config import SENIORITY_SALARY_MULT


def generate_compensation(csvs: dict, profile: dict, employment: dict) -> dict:
    """
    Genera la informacion de compensacion. Aplica:
    - R06: salario coherente con job_title, country, department
    - R07: currency coherente con country
    - R08: IBAN comienza con codigo de pais
    """
    country_iso = profile["country"]
    department = employment["department"]
    seniority = employment["_seniority_level"]

    # --- Buscar rango salarial para (country, department) ---
    salary_row = filter_rows(csvs["salary_ranges"],
                             country_iso=country_iso, department=department)
    if not salary_row:
        # Fallback a Espana
        salary_row = filter_rows(csvs["salary_ranges"],
                                 country_iso="ES", department=department)
    salary_data = salary_row[0]
    currency = salary_data["currency"]

    # --- Calcular salario base anual ---
    s_min = float(salary_data["salary_min_annual"])
    s_baseline = float(salary_data["salary_baseline_annual"])
    s_max = float(salary_data["salary_max_annual"])

    # Aplicar multiplicador por seniority
    mult = SENIORITY_SALARY_MULT.get(seniority, 1.0)
    target = s_baseline * mult

    # Distribucion normal alrededor del target, recortada a [s_min, s_max]
    sigma = (s_max - s_min) / 6  # ~99% dentro del rango
    annual_salary = max(s_min, min(s_max, random.gauss(target, sigma)))

    # Convertir a mensual (en EU son 12 o 14 pagas; usamos 14 paises latinos+ES, 12 resto)
    if country_iso in ("ES", "IT", "PT", "AR", "BR", "CL", "CO", "MX", "PE"):
        extra_payments = random.choice([12, 14])
    else:
        extra_payments = 12

    base_salary_monthly = round(annual_salary / extra_payments, 2)

    # --- Otros conceptos ---
    # Allowances: complemento de transporte/comida (~5-15% del salario base)
    allowances = round(base_salary_monthly * random.uniform(0.05, 0.15), 2)

    # Pagas extra prorrateadas
    extra_payments_prorated = random.choice([True, False])

    # Deducciones (~25-40% del bruto)
    gross_monthly = base_salary_monthly + allowances
    deductions = round(gross_monthly * random.uniform(0.25, 0.40), 2)

    # Tipo de retencion (R18: dentro de rangos legales)
    withholding_rate = round(random.uniform(0.10, 0.45), 4)

    # IBAN coherente con pais (R08)
    bank_account_iban = generate_iban(country_iso)

    # Coste estimado de la empresa (~30-35% mas que el bruto del empleado)
    estimated_company_cost = round(gross_monthly * random.uniform(1.30, 1.40), 2)

    # Notas opcionales (15% de probabilidad)
    compensation_notes = None
    if random.random() < 0.15:
        notes_pool = filter_rows(csvs["note_templates"], note_type="compensation_notes")
        if notes_pool:
            from helpers import weighted_choice
            compensation_notes = weighted_choice(notes_pool, "weight", "note_text")

    return {
        "base_salary_monthly": base_salary_monthly,
        "currency": currency,
        "allowances": allowances,
        "extra_payments": extra_payments,
        "extra_payments_prorated": extra_payments_prorated,
        "deductions": deductions,
        "withholding_rate": withholding_rate,
        "bank_account_iban": bank_account_iban,
        "estimated_company_cost": estimated_company_cost,
        "compensation_notes": compensation_notes,
    }
