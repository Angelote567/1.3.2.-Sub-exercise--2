"""
resume_pipeline.py
==================
Script de reanudacion del pipeline.

Si tu generacion se interrumpio (cierre de terminal, error de red, etc.),
ejecuta este script en lugar de pipeline.py. Detectara automaticamente
desde donde se quedo y solo generara los empleados que te faltan.

USO:
    python3 resume_pipeline.py

Lee tu ID_OFFSET y N_OUTPUTS de config.py para saber tu rango asignado.
Consulta MongoDB y detecta cual es la ultima secuencia ya insertada por ti.
Solo genera los que faltan.
"""

import logging
import random
import re
import time
from helpers import weighted_choice, to_datetime, generate_employee_id
from csv_loader import load_all_csvs
from coherence_rules import validate_employee
from mongodb_client import get_sink, MongoSink

from generators.profile import generate_profile
from generators.employment import generate_employment
from generators.compensation import generate_compensation
from generators.documentation import generate_documentation
from generators.osh import generate_osh
from generators.social_security import generate_social_security
from generators.resources import generate_resources
from generators.exit_process import generate_exit
from generators.history import generate_history

from config import (
    N_OUTPUTS, BATCH_SIZE, RANDOM_SEED, ID_OFFSET,
    LOG_LEVEL, LOG_PROGRESS_EVERY,
)


# =============================================================================
# LOGGING
# =============================================================================
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL),
    format="%(asctime)s | %(levelname)-7s | %(name)-20s | %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("resume")


# =============================================================================
# SERIALIZACION PARA MONGODB
# =============================================================================
def _serialize_dates(obj):
    """Convierte recursivamente date -> datetime."""
    import datetime as dt
    if isinstance(obj, dt.datetime):
        return obj
    if isinstance(obj, dt.date):
        return to_datetime(obj)
    if isinstance(obj, dict):
        return {k: _serialize_dates(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_serialize_dates(x) for x in obj]
    return obj


# =============================================================================
# DETECCION DEL PUNTO DE REANUDACION
# =============================================================================
def detect_last_sequence(sink) -> int:
    """
    Detecta cual es la ultima secuencia ya insertada en MongoDB
    dentro del rango asignado a este usuario.

    Retorna: la ultima secuencia encontrada (entero), o ID_OFFSET si no hay nada.
    Asi, el siguiente empleado a generar sera (last + 1).
    """
    # Solo funciona si el sink es MongoDB (no JSONL)
    if not isinstance(sink, MongoSink):
        logger.warning("El sink no es MongoDB. No se puede detectar reanudacion. Empezando desde el principio.")
        return ID_OFFSET

    my_min = ID_OFFSET + 1
    my_max = ID_OFFSET + N_OUTPUTS

    logger.info(f"Buscando empleados ya insertados en mi rango ({my_min} - {my_max})...")

    # Pipeline de agregacion: extraer la secuencia (ultimo numero del employee_id)
    # y quedarse con el maximo dentro del rango
    pipeline = [
        # Filtrar solo empleados con formato XX-XXX-NNNNNN
        {"$match": {"profile.employee_id": {"$regex": "-[0-9]{6}$"}}},
        # Extraer la secuencia numerica
        {"$addFields": {
            "_seq": {
                "$toInt": {
                    "$arrayElemAt": [{"$split": ["$profile.employee_id", "-"]}, -1]
                }
            }
        }},
        # Filtrar por mi rango
        {"$match": {"_seq": {"$gte": my_min, "$lte": my_max}}},
        # Quedarme con el maximo
        {"$group": {"_id": None, "max_seq": {"$max": "$_seq"}, "count": {"$sum": 1}}},
    ]

    result = list(sink.collection.aggregate(pipeline))

    if not result:
        logger.info(f"No hay empleados previos en mi rango. Empezando desde la secuencia {my_min}.")
        return ID_OFFSET

    last_seq = result[0]["max_seq"]
    count = result[0]["count"]
    logger.info(f"Encontrados {count} empleados ya insertados en mi rango.")
    logger.info(f"Ultima secuencia generada: {last_seq}")
    logger.info(f"Continuando desde la secuencia {last_seq + 1}.")
    return last_seq


# =============================================================================
# GENERACION DE UN EMPLEADO COMPLETO (igual que pipeline.py)
# =============================================================================
def generate_employee(csvs: dict, sequence: int) -> dict:
    """Genera un empleado completo con sus 9 bloques."""
    country_iso = weighted_choice(csvs["countries"], "weight", "iso_code")
    wc_pool = [w for w in csvs["work_centers"] if w["country_iso"] == country_iso]
    if not wc_pool:
        wc_pool = [w for w in csvs["work_centers"] if w["country_iso"] == "ES"]
    work_center = random.choice(wc_pool)

    employee_id = generate_employee_id(country_iso, work_center["work_center_code"], sequence)

    profile = generate_profile(csvs, employee_id, work_center)
    employment = generate_employment(csvs, profile, work_center)
    exit_block = generate_exit(csvs, employment)

    if exit_block.get("termination_date"):
        td = exit_block["termination_date"]
        hd = employment["hire_date"]
        months_real = (td - hd).days // 30
        if employment["probation_period"] > months_real:
            employment["probation_period"] = max(0, months_real)

    compensation = generate_compensation(csvs, profile, employment)
    documentation = generate_documentation(csvs, profile, employment)
    osh = generate_osh(csvs, employment)
    social_security = generate_social_security(csvs, profile, employment)
    resources = generate_resources(csvs, employment, exit_block)
    history = generate_history(csvs, employment, exit_block)

    employment_clean = {k: v for k, v in employment.items() if not k.startswith("_")}

    return {
        "profile": profile,
        "employment": employment_clean,
        "compensation": compensation,
        "documentation": documentation,
        "history": history,
        "osh": osh,
        "social_security": social_security,
        "resources": resources,
        "exit": exit_block,
    }


# =============================================================================
# PIPELINE DE REANUDACION
# =============================================================================
def run():
    if RANDOM_SEED is not None:
        # IMPORTANTE: en reanudacion NO usamos seed fija, porque generaria
        # otra vez los mismos empleados que ya estan insertados (duplicados).
        # Usamos una semilla derivada del momento actual para garantizar
        # que los nuevos empleados son distintos.
        random.seed()
        logger.info("Reanudacion: seed aleatoria (no se usa RANDOM_SEED para evitar duplicados)")

    start = time.time()
    logger.info("=" * 60)
    logger.info("MODO REANUDACION")
    logger.info(f"  ID_OFFSET asignado: {ID_OFFSET}")
    logger.info(f"  N_OUTPUTS objetivo: {N_OUTPUTS}")
    logger.info(f"  Rango de secuencias: {ID_OFFSET + 1} - {ID_OFFSET + N_OUTPUTS}")
    logger.info("=" * 60)

    # Cargar CSVs
    csvs = load_all_csvs()

    # Conectar al sink
    sink = get_sink()

    # Detectar punto de reanudacion
    last_seq = detect_last_sequence(sink)
    start_seq = last_seq + 1
    end_seq = ID_OFFSET + N_OUTPUTS

    if start_seq > end_seq:
        logger.info("=" * 60)
        logger.info("Tu rango ya esta completo. No hay nada que generar.")
        logger.info(f"  Generados: {N_OUTPUTS} / {N_OUTPUTS}")
        logger.info("=" * 60)
        sink.close()
        return

    n_pendientes = end_seq - start_seq + 1
    logger.info(f"Empleados pendientes: {n_pendientes}")
    logger.info(f"Generando del {start_seq} al {end_seq}")
    logger.info("=" * 60)

    # Generar empleados pendientes
    batch = []
    n_invalid = 0
    n_generated = 0
    violations_by_rule = {}

    for seq in range(start_seq, end_seq + 1):
        emp = generate_employee(csvs, sequence=seq)

        is_valid, violations = validate_employee(emp)
        if not is_valid:
            n_invalid += 1
            for v in violations:
                rule = v.split(":")[0]
                violations_by_rule[rule] = violations_by_rule.get(rule, 0) + 1

        emp_serialized = _serialize_dates(emp)
        batch.append(emp_serialized)
        n_generated += 1

        if len(batch) >= BATCH_SIZE:
            sink.insert_batch(batch)
            batch.clear()

        if n_generated % LOG_PROGRESS_EVERY == 0:
            elapsed = time.time() - start
            rate = n_generated / elapsed if elapsed > 0 else 0
            eta = (n_pendientes - n_generated) / rate if rate > 0 else 0
            logger.info(f"  Progreso: {n_generated}/{n_pendientes} ({rate:.1f} empleados/s, ETA {eta:.0f}s)")

    if batch:
        sink.insert_batch(batch)

    elapsed = time.time() - start
    logger.info("=" * 60)
    logger.info(f"REANUDACION COMPLETADA en {elapsed:.1f}s")
    logger.info(f"  Empleados generados en esta ejecucion: {n_generated}")
    logger.info(f"  Total documentos en mi rango: ya completos ({N_OUTPUTS})")
    if n_invalid:
        logger.info(f"  Con violaciones: {n_invalid} ({100*n_invalid/n_generated:.2f}%)")
        for rule, count in sorted(violations_by_rule.items()):
            logger.info(f"    {rule}: {count}")
    logger.info("=" * 60)

    sink.close()


if __name__ == "__main__":
    run()
