# HR Database - Synthetic Data Generator

Generador de base de datos sintetica de RRHH para MongoDB, basado en el modelo del PDF de la asignatura.

## Estructura del proyecto

```
project/
├── config.py              # Variables globales (N_OUTPUTS, MongoDB URI, etc.)
├── csv_loader.py          # Carga todos los CSVs en memoria
├── helpers.py             # Funciones comunes (random ponderado, fechas, IDs...)
├── coherence_rules.py     # Validador de las 18 reglas del PDF (R01-R18)
├── mongodb_client.py      # Cliente MongoDB con fallback a JSONL
├── pipeline.py            # Orquestador principal
├── generators/
│   ├── profile.py         # Bloque EmployeeProfile
│   ├── employment.py      # Employment Information
│   ├── compensation.py    # Compensation
│   ├── documentation.py   # Documentation
│   ├── history.py         # History
│   ├── osh.py             # Occupational Safety and Health
│   ├── social_security.py # Social Security
│   ├── resources.py       # Assigned Resources
│   └── exit_process.py    # Exit Process
├── data/
│   └── csvs/              # 31 CSVs con datos base
└── requirements.txt
```

## Uso

### 1. Instalar dependencias

```bash
pip install -r requirements.txt
```

### 2. (Opcional) Configurar MongoDB

Editar `config.py`:

```python
MONGO_URI = "mongodb://localhost:27017"   # O tu URI de Atlas
MONGO_DB_NAME = "hr_database"
MONGO_COLLECTION = "employees"
N_OUTPUTS = 1000          # Cambiar a 1_500_000 para el dataset final
BATCH_SIZE = 100          # Subir a 10_000 para 1.5M registros
```

Tambien se puede pasar la URI por variable de entorno:

```bash
export MONGO_URI="mongodb://user:pass@host:27017/"
```

### 3. Ejecutar

```bash
python pipeline.py
```

Si MongoDB no esta disponible, el pipeline cae automaticamente a un fallback JSONL
y genera `output_employees.jsonl` en la raiz del proyecto.

## Reglas de coherencia implementadas

Las 18 reglas del PDF (R01-R18) se validan despues de generar cada empleado.
Al final, se muestra el numero de violaciones por regla.

| Regla | Validacion |
|---|---|
| R01 | Edad minima al contratar (>= 16 anos) |
| R02 | Edad realista (18-67) |
| R03 | ss_enrollment_date >= hire_date |
| R04 | termination_date >= hire_date |
| R05 | probation_period <= duracion del empleo |
| R06 | salario en rango por country/department |
| R07 | currency coherente con country |
| R08 | IBAN comienza con codigo pais (UE) |
| R09 | postal_code coherente con city/country |
| R10 | Si no terminado, exit fields vacios |
| R11 | Si terminado, exit fields completos |
| R12 | Nombre consistente |
| R13 | Email derivado del nombre |
| R14 | Diversidad de nombres (cross-record) |
| R15 | Dependientes coherentes con marital_status |
| R16 | osh_training_date >= hire_date |
| R17 | asset_return_date solo si terminado |
| R18 | withholding_rate en rango legal |

## Salida esperada

```
17:23:45 | INFO    | pipeline | Iniciando generacion de 1000 empleados (batch=100)
17:23:45 | INFO    | csv_loader | Cargados 31 CSVs correctamente
17:23:45 | INFO    | mongodb_client | Conectado a MongoDB
17:23:45 | INFO    | pipeline |   Progreso: 100/1000 (520 empleados/s)
...
17:23:47 | INFO    | pipeline | GENERACION COMPLETADA en 1.9s
17:23:47 | INFO    | pipeline |   Total insertados: 1000
17:23:47 | INFO    | pipeline |   Empleados con violaciones: 0 (0.00%)
```

## Escalado a 1.5M registros

Para el dataset final, ajustar en `config.py`:

```python
N_OUTPUTS = 1_500_000
BATCH_SIZE = 10_000     # MongoDB acepta hasta 100k por insert_many
```

Tiempo estimado: ~50 minutos a 500 empleados/s en una VM modesta.
Memoria: la lista `all_employees_for_validation` puede consumir mucha RAM con 1.5M.
Para esa escala, conviene desactivar la validacion R14 cross-record o hacerla por chunks.
